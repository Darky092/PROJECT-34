﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _1window
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 pd = new Window1();
            pd.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void green_Click(object sender, RoutedEventArgs e)
        {
            greenn.Background = Brushes.Green;
            if (greenn.Background == Brushes.Green) 
            {
                yeloww.Background = Brushes.White;
                redd.Background = Brushes.White;


            }
        }

        private void yelow_Click(object sender, RoutedEventArgs e)
        {
            yeloww.Background = Brushes.Yellow;
            if (yeloww.Background == Brushes.Yellow) 
            {
                greenn.Background= Brushes.White;
                redd.Background= Brushes.White;
            }
        }

        private void red_Click(object sender, RoutedEventArgs e)
        {
            redd.Background = Brushes.Red;
            if (redd.Background == Brushes.Red) 
            {
                greenn.Background = Brushes.White;
                yeloww.Background= Brushes.White;
            }
        }
    }
}
