﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _1window
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }


        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow pA = new MainWindow();
            pA.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window2 pB = new Window2();
            pB.Show();
            this.Close();
        }

        private void funnyButton_Click(object sender, RoutedEventArgs e)
        {
            int x = 450;
            int y = 800;
            Random random = new Random();
            double w = random.Next(0, y);
            double h = random.Next(0, x);
            funnyButton.Margin = new Thickness(w, h, 0, 0);

        }
    }
}
